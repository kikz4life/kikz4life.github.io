'use client'

import Head from 'next/head'
import styles from './about.module.scss'
import Container from '../components/Container'
import ToolIcons from '../components/ToolIcons'
import Header from '../components/Header'
import { Row, Col } from 'react-bootstrap';
import { motion } from 'framer-motion'

interface ListItem {
  name: string
  link: string
}

interface ListProps {
  list: ListItem[]
  title: string
}

export default function About() {
  const PEOPLE: ListItem[] = [
    {
      name: 'Wes Bos',
      link: 'https://wesbos.com/',
    },
    {
      name: 'Chris Coyier',
      link: 'https://css-tricks.com/',
    },
    {
      name: 'Brad Traversy',
      link: 'https://traversymedia.com/',
    },
    {
      name: 'Kent Dodds',
      link: 'https://kentcdodds.com/',
    },
  ]

  const PODCAST: ListItem[] = [
    {
      name: 'Syntax.fm',
      link: 'https://syntax.fm/',
    },
    {
      name: 'Shop Talk Show',
      link: 'https://shoptalkshow.com/',
    },
    {
      name: 'Front End Happy Hour',
      link: 'https://frontendhappyhour.com/',
    },
  ]

  const INSPIRATIONS: ListItem[] = [
    {
      name: 'Codepen',
      link: 'https://codepen.io/',
    },
    {
      name: 'Smashing Magazine',
      link: 'https://www.smashingmagazine.com/',
    },
    {
      name: 'Design Code',
      link: 'https://designcode.io/',
    },
  ]

  const makeList = ({ list, title }: ListProps) => (
    <div className={styles.box}>
      <motion.h1
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1, transition: { delay: 1 } }}
      >
        {title}
      </motion.h1>
      <motion.ul
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1, transition: { delay: 1.2 } }}
      >
        {list.map((p, key) => (
          <li key={`${p.name}-${key}`}>
            <a href={p.link} rel="noopener noreferrer" target="_blank">
              {p.name}
            </a>
          </li>
        ))}
      </motion.ul>
    </div>
  )

  return (
    <Container>
      <Head>
        <meta
          name="description"
          content="I'm Dean, love web development."
        />
        <title>About Me | Dean Francis Casili</title>
      </Head>
      <Header active="about" />
      <div className={styles.about}>
        <motion.h1
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          Hello World!
        </motion.h1>

        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
        >
          I'm Dean Francis Casili, a passionate developer for more than 13 years,
          a lifelong learner, and someone who believes that growth never stops.
          Outside of coding, I love exploring new places, finding inspiration in nature,
          and admiring the creativity behind architecture and design.
          From quiet beach escapes in the Philippines to the vibrant energy of
          city life, I enjoy learning about different cultures, tasting new flavors,
          and meeting people from all walks of life. Every journey, whether in
          life or in code, is an opportunity to grow, connect, and discover
          something new.
        </motion.p>

        <motion.blockquote
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
        >
          <p>“Never go on trips with anyone you do not love.” ― Hemmingway</p>
        </motion.blockquote>

        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
        >
          I love playing basketball (I&#39;m a huge NBA fan), reading manga,
          watching anime, Friends, The Big Bang Theory and Dota 2 tournament.
        </motion.p>
        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
        >
          I also like Ancient History, Astronomy and Physics. From the mystery
          of building the Great Pyramid Giza to the countless possibility of
          another civilization million miles away, to the question of the
          discovery of parallel universe. (I just hope I&#39;m tall, rich and good
          looking man somewhere there. 😂) Those are the questions that makes me
          wonder at night.
        </motion.p>

        <motion.blockquote
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
        >
          <p>
            “In this bright future you can&#39;t forget your past.” ― Bob Marley
          </p>
        </motion.blockquote>

        <motion.h2
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.3 } }}
        >
          Career
        </motion.h2>

        <Row>
          <Col lg={12}>
            <motion.div>
              <motion.h4>Senior Full-stack Developer</motion.h4>
              <motion.h5>June 2018 – Mar 2025</motion.h5>
              <motion.p>Deltek Inc</motion.p>
              <motion.p>
                Led a cross-functional team of three developers and three QA engineers in the
                development of the Learning and Development module, employing Test-Driven
                Development (TDD), conducting rigorous code reviews, and overseeing the
                implementation of new features. Maintained close collaboration with the Project
                Development Manager and System Architect to ensure architectural consistency and
                project alignment
              </motion.p>
            </motion.div>
            <motion.div>
              <motion.h4>Full-stack Developer</motion.h4>
              <motion.h5>June 2015 - June 2018</motion.h5>
              <motion.p>BIG OS Corp</motion.p>
              <motion.p>
                Solo developer and architect for an australian client. Implemented robust application
                using Laravel + React.
              </motion.p>
            </motion.div>
          </Col>
          {/*<Col lg={6}>
            <motion.h3
              initial={{ y: 50, opacity: 0 }}
              animate={{ y: 0, opacity: 1, transition: { delay: 0.2 } }}
            >
              Education
            </motion.h3>
            <motion.div>
              <motion.h4>Bachelor of Science Information Technology</motion.h4>
              <motion.h5>2007 - 2011</motion.h5>
              <motion.p>Ateneo de Naga University</motion.p>
            </motion.div>
          </Col>*/}
        </Row>

        <motion.h2
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.5 } }}
        >
          Uses
        </motion.h2>

        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.6 } }}
        >
          Big fan of open source. I try to use them all the time with my
          projects. It first happened when I was forced to develop in a Linux
          machine. Ubuntu to be precise. It was daunting at first, Setting up
          virtual host, Editing files using nano or vim, Just using
          terminal/command line is very intimidating for a noob like myself. I
          remember when I was stuck inside VIM for almost an hour. LOL (damn{' '}
          <code>:q!</code>) It took me quite a while to adjust from using
          Windows to Linux. But once you put your foot on that water there is no
          turning back. To be honest, I can't see myself developing on a Windows
          machine again. Not that I have anything against Windows. It's just
          that I'm so comfortable with Linux right now I'm just looking for the
          best distro's to try out.
        </motion.p>

        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.6 } }}
        >
          {' '}
          The following are languages, libraries, frameworks and tools that I
          use when creating a website.
        </motion.p>

        <ToolIcons delay={0.7} limit={1000} />

        <motion.p
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1, transition: { delay: 0.9 } }}
        >
          I follow a lot of awesome people in the industry, listen to web
          development podcasts and read blogs. If you want to check them out
          here are some.
        </motion.p>

        <div className={styles.list}>
          {makeList({ list: PEOPLE, title: 'People' })}
          {makeList({ list: PODCAST, title: 'Podcast' })}
          {makeList({ list: INSPIRATIONS, title: 'Inspirations' })}
        </div>
      </div>
    </Container>
  )
}